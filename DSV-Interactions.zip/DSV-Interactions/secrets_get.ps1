# Get the variables from the file that holds them
$lines=Get-Content -Path ./.env
$client_id=($lines[0] -split "=")[1]
$client_secret_id=($lines[1] -split "=")[1]
$tenant_url=($lines[2] -split "=")[1]

# Set the new password for the secret
$new_passwd="Th1s_15-T43-n0w-P@55w0rd!!_via_PowerShell"

# Build the login payload based on the variables
$payload=@"
{
    "grant_type":"client_credentials",
    "client_id":"$client_id",
    "client_secret":"$client_secret_id"
}
"@

# Login to the DSV tenant to retrieve the BearerToken
$access_token=(Invoke-RestMethod -Method 'Post' -Uri $tenant_url"/v1/token" -Body $payload).accessToken

write-host "------------------------------------------------------------------"
# Use PWSH to retrieve the secret and show the secret data from aws/ec2-database
$headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$headers.Add("Authorization", "Bearer $access_token")
$body = @"

"@
$response = Invoke-RestMethod $tenant_url'/v1/secrets/aws/ec2-database' -Method 'GET' -Headers $headers -Body $body
write-host "The host that is in the secret is: "($response).data.host
write-host "The user that is in the secret is: "($response).data.user
write-host "The password that is in the secret is: "($response).data.password

# Use PWSH to change the password in the secret aws/ec2-database
write-host "------------------------------------------------------------------"
write-host "Changing password from "($response).data.password" to "$new_passwd

$headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$headers.Add("Authorization", "Bearer $access_token")
$body = @"
{
    "data": {
      "password": "$new_passwd"
    },
    "description":"Password set via PowerShell"
}
"@
$response = Invoke-RestMethod $tenant_url'/v1/secrets/aws/ec2-database' -Method 'PUT' -Headers $headers -Body $body

# Get the current values
$response = Invoke-RestMethod $tenant_url'/v1/secrets/aws/ec2-database' -Method 'GET' -Headers $headers -Body $body
write-host "After the changed password call this is the current data"
write-host "The host that is in the secret is: "($response).data.host
write-host "The user that is in the secret is: "($response).data.user
write-host "The password that is in the secret is: "($response).data.password
import requests,os
import json
from dotenv import load_dotenv, find_dotenv
import urllib3
urllib3.disable_warnings()

# Get the needed variables from the file
load_dotenv(find_dotenv())
tenant_url=os.getenv('tenant_url')
client_id=os.getenv('client_id')
client_secret_id=os.getenv('client_secret_id')

new_passwd="Th1s_15-T43-n0w-P@55w0rd!!_via_Python"

# Build the login payload based on the variables
payload={
    "grant_type":"client_credentials",
    "client_id":client_id,
    "client_secret":client_secret_id
}

data=json.dumps(payload)

# Login to the DSV tenant to retrieve the BearerToken
url = tenant_url+"/v1/token"
response = requests.post(url, data=data, verify=False)
access_token=json.loads(response.text)["accessToken"]

print("------------------------------------------------------------------")

# Use Python to retrieve the secret and show the secret data from aws/ec2-database
headers = {
     'Authorization': 'Bearer '+access_token+'',
     'Content-Type': 'application/json'
    }
method='GET'
response = requests.request(method, tenant_url+'/v1/secrets/aws/ec2-database', headers=headers, data=payload, verify=False)
print("The host that is in the secret is: "+json.loads(response.text)['data']['host'])
print("The user that is in the secret is: "+json.loads(response.text)['data']['user'])
print("The password that is in the secret is: "+json.loads(response.text)['data']['password'])

# Use Python to change the password in the secret aws/ec2-database
print("------------------------------------------------------------------")
print("Changing password from "+json.loads(response.text)['data']['password']+" to "+new_passwd)

payload={
    "data": {
      "password": new_passwd
    },
    "description":"Password set via Python"
}
method='PUT'
response = requests.request(method, tenant_url+'/v1/secrets/aws/ec2-database', headers=headers, data=json.dumps(payload), verify=False)

# Get the current values from the secret
method='GET'
response = requests.request(method, tenant_url+'/v1/secrets/aws/ec2-database', headers=headers, verify=False)
print("The host that is in the secret is: "+json.loads(response.text)['data']['host'])
print("The user that is in the secret is: "+json.loads(response.text)['data']['user'])
print("The password that is in the secret is: "+json.loads(response.text)['data']['password'])

# Get the variables from the file that holds them
file_data="`cat .env`"
client_id="`echo $file_data | cut -d "=" -f 2 | cut -d " " -f1`"
client_secret_id="`echo $file_data | cut -d "=" -f 3 | cut -d " " -f1`"
tenant_url="`echo $file_data | cut -d "=" -f 4`"

# Set the new password for the secret
new_passwd=""Th1s_15-T43-n0w-P@55w0rd!!_via_Bash""

# Build the login payload based on the variables
payload='{ 
        "grant_type":"client_credentials",
        "client_id":"'$client_id'",
        "client_secret":"'$client_secret_id'"
        }'

# Login to the DSV tenant to retrieve the BearerToken
accessToken=$(curl --silent -k -X POST -H "Content-Type: application/json" -d "$payload"  $tenant_url"/v1/token" | jq '.accessToken' | tr -d \")

echo "------------------------------------------------------------------"

# Use BASH to retrieve the secret and show the secret data from aws/ec2-database
response=$(curl --silent -X GET --oauth2-bearer $accessToken -H "Content-Type: application/json" \
        $tenant_url"/v1/secrets/aws/ec2-database")

echo "The host that is in the secret is: "`echo $response | jq '.data.host' | tr -d \"`
echo "The user that is in the secret is: "`echo $response | jq '.data.user' | tr -d \"`
echo "The password that is in the secret is: "`echo $response | jq '.data.password' | tr -d \"`

# Use BASH to change the password in the secret aws/ec2-database
echo "------------------------------------------------------------------"
echo "Changing password from "`echo $response | jq '.data.password'`" to "$new_passwd

payload='{
            "data": {
              "password": "'$new_passwd'"
            },
            "description":"Password set via Bash"
        }'

response=$(curl --silent -X PUT --oauth2-bearer $accessToken -H "Content-Type: application/json" \
        -d "$payload" $tenant_url"/v1/secrets/aws/ec2-database")
# Get the current values

echo "The host that is in the secret is: "`echo $response | jq '.data.host' | tr -d \"`
echo "The user that is in the secret is: "`echo $response | jq '.data.user' | tr -d \"`
echo "The password that is in the secret is: "`echo $response | jq '.data.password' | tr -d \"`
